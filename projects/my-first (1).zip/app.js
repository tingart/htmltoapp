const result = document.querySelector('#result');
document.querySelector('#native-check').addEventListener('click', async () => {
  if (!window.webOS) { result.textContent = 'Runtime API not loaded yet.'; return; }
  const info = await webOS.device.getInfo();
  result.textContent = info.isNative ? 'Running inside Tauri on ' + info.platform + '.' : 'Browser preview — native APIs use safe fallbacks.';
});